package jp.co.example.company.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.example.company.entity.Criteria;
import jp.co.example.company.entity.User;
import jp.co.example.company.entity.UserRequest;
import jp.co.example.company.mapper.PageMapper;

@Service
public class PageServiceImpl implements PageService {
    private static final Logger logger = LoggerFactory.getLogger(PageServiceImpl.class);
    @Autowired
    private PageMapper pageMapper;

    @Override
    public List<UserRequest> getPageList(Criteria cri) throws Exception {
        logger.info("(service)getPageList()........... " + cri);
        return pageMapper.getPageList(cri);
    }

    @Override
    public int getTotal(Criteria cri) throws Exception {
        logger.info("service getTotal");
        return pageMapper.getTotal(cri);
    }

    @Override
    public List<User> getUserList(Criteria cri) throws Exception {
        logger.info("(service)getUserList()........... " + cri);
        return pageMapper.getUserList(cri);
    }

    @Override
    public int getUser(Criteria cri) throws Exception {
        logger.info("service getUser");
        return pageMapper.getUser(cri);
    }

}
