package jp.co.example.company.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import jp.co.example.company.entity.Criteria;
import jp.co.example.company.entity.User;
import jp.co.example.company.entity.UserRequest;

@Mapper
public interface PageMapper {

    public void pageEnroll(UserRequest userRequest);

    List<UserRequest> getPageList(Criteria cri);

    int getTotal(Criteria cri);

    List<User> getUserList(Criteria cri);

    int getUser(Criteria cri);

    void insertRequest(UserRequest request);
}
