package jp.co.example.company.service;

import java.util.List;

import jp.co.example.company.entity.UserRequest;

public interface UserRequestService {
    public List<UserRequest> findUserRequests();

    void updateStatus(int id, String status);

    void saveRequest(UserRequest request);

}
