package jp.co.example.company.dao;

import java.util.List;

import jp.co.example.company.entity.Admin;
import jp.co.example.company.entity.User;

public interface UserDao {
    User findByLoginId(String loginId);

    Admin findByAuthorityId(Integer authorityId);

    public List<User> findAll();

    User findById(Long id);

    void update(User user);

}
