package jp.co.example.company.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jp.co.example.company.entity.Criteria;
import jp.co.example.company.entity.PageDto;
import jp.co.example.company.entity.User;
import jp.co.example.company.entity.UserRequest;
import jp.co.example.company.service.LoginService;
import jp.co.example.company.service.PageService;
import jp.co.example.company.service.UserRequestService;

@Controller
public class SearchController {

    private final LoginService loginService;
    private final PageService pageService;
    private UserRequestService userRequestService;

    @Autowired
    public SearchController(LoginService loginService, PageService pageService, UserRequestService userRequestService) {
        this.loginService = loginService;
        this.pageService = pageService;
        this.userRequestService = userRequestService;
    }

    @GetMapping("/user/search/all")
    public String search(HttpSession session, @ModelAttribute("cri") Criteria cri,
            @RequestParam(value = "reset", required = false) Boolean reset, Model model,
            HttpServletResponse response) throws Exception {

        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            return "redirect:/login?error=unauthorized";
        }
        if (Boolean.TRUE.equals(reset)) {
            cri = new Criteria(); // 조건 초기화
        }
        if (cri.getPageNum() <= 0)
            cri.setPageNum(1);
        if (cri.getAmount() <= 0)
            cri.setAmount(15);

        int total = pageService.getUser(cri); // 총 데이터 개수

        // 페이지 번호 보정 (전체 페이지 수 계산)
        int lastPage = (int) Math.ceil((double) total / cri.getAmount());
        if (lastPage == 0) {
            lastPage = 1; // 데이터가 없는 경우도 1페이지로 보정
        }
        if (cri.getPageNum() > lastPage) {
            cri.setPageNum(lastPage);
        }

        List<User> usergetList = pageService.getUserList(cri);

        model.addAttribute("cri", cri);
        model.addAttribute("loginId", user.getEmployeeName());
        model.addAttribute("isAdmin", user.getAuthorityId() == 1);
        model.addAttribute("user", user);
        model.addAttribute("usergetList", usergetList);
        model.addAttribute("pageMaker", new PageDto(cri, total));

        // 응답 캐시 방지
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        return "user/search";
    }

    @GetMapping("/request")
    public String requestPage(HttpSession session, Criteria cri, Model model,
            HttpServletResponse response) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            return "redirect:/login?error=unauthorized";// 로그인되지 않은 경우 로그인 페이지로 리다이렉트
        }
        model.addAttribute("loginId", user.getEmployeeName());
        model.addAttribute("isAdmin", user.getAuthorityId() == 1);
        return "user/request"; // 사용자 요청 페이지로 이동
    }

    @PostMapping("/user/request/save")
    public String saveRequest(@RequestParam("requestContent") String requestContent,
            @RequestParam("message") String message,
            HttpSession session,
            HttpServletResponse response,
            RedirectAttributes redirectAttributes) {

        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login?error=unauthorized";
        }

        if (requestContent.trim().isEmpty() || message.trim().isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "依頼内容とメッセージは必須です。");
            return "redirect:/request";
        }

        UserRequest request = new UserRequest();
        request.setLoginId(user.getLoginId());
        request.setEmployeeId(user.getEmployeeId());
        request.setRequestContent(requestContent);
        request.setMessage(message);
        request.setStatus("未対応");

        userRequestService.saveRequest(request);

        // 성공 메시지 추가
        redirectAttributes.addFlashAttribute("success", "要請が正常に登録されました。");

        return "redirect:/request";
    }

}
