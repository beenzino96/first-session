package jp.co.example.company.controller;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jp.co.example.company.entity.Criteria;
import jp.co.example.company.entity.PageDto;
import jp.co.example.company.entity.User;
import jp.co.example.company.entity.UserRequest;

import jp.co.example.company.service.PageService;
import jp.co.example.company.service.UserRequestService;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController {

    private final UserRequestService userRequestService;

    private final PageService pageService;

    public AdminController(UserRequestService userRequestService, PageService pageService) {
        this.pageService = pageService;
        this.userRequestService = userRequestService;
    }

    @GetMapping("/admins/admin")
    public String adminsearch(HttpSession session, Criteria cri, Model model,
            HttpServletResponse response) throws Exception {
        cri.setAmount(5);
        User user = (User) session.getAttribute("user");
        UserRequest userRequest = (UserRequest) session.getAttribute("userRequest");
        if (user == null) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            return "redirect:/login?error=unauthorized";
        }
        List<UserRequest> userList = pageService.getPageList(cri);
        int total = pageService.getTotal(cri);

        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        model.addAttribute("loginId", user.getEmployeeName());
        model.addAttribute("isAdmin", user.getAuthorityId() == 1);
        model.addAttribute("user", user);
        model.addAttribute("userlist", userList); // 뷰에서 맞
        model.addAttribute("userRequest", userRequest);
        PageDto pageMaker = new PageDto(cri, total);
        model.addAttribute("pageMaker", pageMaker);
        return "admins/admin";

    }

    @GetMapping("/user/search")
    public String search(HttpSession session, Criteria cri, Model model,
            HttpServletResponse response) throws Exception {

        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            return "redirect:/login?error=unauthorized";
        }
        List<User> usergetList = pageService.getUserList(cri);
        int total = pageService.getUser(cri);

        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        model.addAttribute("loginId", user.getEmployeeName());
        model.addAttribute("isAdmin", user.getAuthorityId() == 1);
        model.addAttribute("user", user);
        model.addAttribute("usergetList", usergetList); // 뷰에서 맞는 이름으로 변경
        PageDto pageMaker = new PageDto(cri, total);
        model.addAttribute("pageMaker", pageMaker);

        return "user/search";
    }

    @PostMapping("/admins/updateStatus")
    public String updateStatus(@RequestParam("id") int id, HttpSession session,
            @RequestParam("status") String status,
            HttpServletResponse response) {
        User user = (User) session.getAttribute("user");
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);
        if (user == null || user.getAuthorityId() != 1) {
            return "redirect:/login?error=unauthorized";
        }

        userRequestService.updateStatus(id, status);
        return "redirect:/admins/admin"; // 변경 후 목록 새로고침
    }

}
