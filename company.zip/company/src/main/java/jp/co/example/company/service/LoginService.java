package jp.co.example.company.service;

import java.util.List;

import jp.co.example.company.entity.Admin;
import jp.co.example.company.entity.User;

public interface LoginService {
    public User login(String loginId, String password);

    public Admin login(Integer authorityId, String authorityName);

    public List<User> findAll();

    public void updateUser(User user);

    public User findById(Long id);

}
