package jp.co.example.company.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.example.company.entity.Criteria;
import jp.co.example.company.entity.User;
import jp.co.example.company.entity.UserRequest;

public interface PageService {
    public List<UserRequest> getPageList(Criteria cri) throws Exception;

    public int getTotal(Criteria cri) throws Exception;

    public List<User> getUserList(Criteria cri) throws Exception;

    public int getUser(Criteria cri) throws Exception;
}
