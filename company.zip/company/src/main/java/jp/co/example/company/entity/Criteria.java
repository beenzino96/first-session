package jp.co.example.company.entity;

import org.springframework.web.util.UriComponentsBuilder;

import lombok.Data;

@Data
public class Criteria {

    private int pageNum; // 현재 페이지 번호
    private int amount; // 한 페이지에 몇 개 보여줄지
    private String searchWord;
    private String employeeId;

    public Criteria() {
        this(1, 15); // 기본값
    }

    public Criteria(int pageNum, int amount) {
        this.pageNum = pageNum;
        this.amount = amount;
    }

    public int getSkip() {
        return (pageNum - 1) * amount;
    }

    // setPageNum, setAmount는 그냥 필드 세팅만
    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    // 나머지 코드는 동일
}
