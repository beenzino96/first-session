package jp.co.example.company.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Entity

@Getter
@Setter
@Table(name = "users", schema = "myschema")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_id")
    private Long employeeId;

    @NotBlank(message = "氏名を入力してください。")
    @Size(max = 100, message = "氏名は100文字以内で入力してください。")
    @Column(name = "employee_name")
    private String employeeName;

    @NotBlank(message = "氏名（カナ）を入力してください。")
    @Size(max = 100, message = "氏名（カナ）は100文字以内で入力してください。")
    @Column(name = "employee_name_kana")
    private String employeeNameKana;

    @NotNull(message = "部署IDを入力してください。")
    @Min(value = 1, message = "部署IDは1以上の数字で入力してください。")
    @Column(name = "department_id")
    private Integer departmentId;

    @Size(max = 20, message = "電話番号は20文字以内で入力してください。")
    @Column(name = "phone_number")
    private String phoneNumber;

    @NotBlank(message = "ログインIDを入力してください。")
    @Size(max = 50, message = "ログインIDは50文字以内で入力してください。")
    @Column(name = "login_id")
    private String loginId;

    @NotBlank(message = "パスワードを入力してください。")
    @Size(min = 8, max = 100, message = "パスワードは8〜100文字で入力してください。")
    @Column(name = "login_password")
    private String loginPassword;

    @NotNull(message = "権限IDを入力してください。")
    @Min(value = 1, message = "権限IDは1以上の数字で入力してください。")
    @Column(name = "authority_id")
    private Integer authorityId;

    @Column(name = "birth_date")
    private Date birthDate;

    @Column(name = "gender")
    @Pattern(regexp = "^(男|女|その他)?$", message = "性別は「男」「女」「その他」のいずれかを入力してください。")
    private String gender;

    @Size(max = 10, message = "郵便番号は10文字以内で入力してください。")
    @Pattern(regexp = "^\\d{3}-?\\d{4}$", message = "郵便番号は正しい形式（例: 123-4567）で入力してください。")
    @Column(name = "postal_code")
    private String postalCode;

    @Size(max = 255, message = "住所は255文字以内で入力してください。")
    @Column(name = "address")
    private String address;

    @Column(name = "deleted_flag")
    private Boolean deletedFlag;

    // デフォルトコンストラクタ
    public User() {
    }

    // パラメータ付きコンストラクタ
    public User(String employeeName, String employeeNameKana, Integer departmentId, String phoneNumber,
            String loginId, String loginPassword, Integer authorityId, Date birthDate,
            String gender, String postalCode, String address, Boolean deletedFlag) {
        this.employeeName = employeeName;
        this.employeeNameKana = employeeNameKana;
        this.departmentId = departmentId;
        this.phoneNumber = phoneNumber;
        this.loginId = loginId;
        this.loginPassword = loginPassword;
        this.authorityId = authorityId;
        this.birthDate = birthDate;
        this.gender = gender;
        this.postalCode = postalCode;
        this.address = address;
        this.deletedFlag = deletedFlag;

    }
}
