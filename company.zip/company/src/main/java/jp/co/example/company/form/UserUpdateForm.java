package jp.co.example.company.form;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserUpdateForm {
    @NotBlank(message = "氏名を入力してください。")
    @Size(max = 100, message = "氏名は100文字以内で入力してください。")
    private String employeeName;

    @NotBlank(message = "氏名（カナ）を入力してください。")
    @Size(max = 100, message = "氏名（カナ）は100文字以内で入力してください。")
    private String employeeNameKana;

    @NotNull(message = "部署IDを入力してください。")
    @Min(value = 1, message = "部署IDは1以上の数字で入力してください。")
    private Integer departmentId;

    @Size(max = 20, message = "電話番号は20文字以内で入力してください。")
    private String phoneNumber;

    private Date birthDate;

    @Pattern(regexp = "^(男|女|その他)?$", message = "性別は「男」「女」「その他」のいずれかを入力してください。")
    private String gender;

    @Size(max = 10, message = "郵便番号は10文字以内で入力してください。")
    @Pattern(regexp = "^\\d{3}-?\\d{4}$", message = "郵便番号は正しい形式（例: 123-4567）で入力してください。")
    private String postalCode;

    @Size(max = 255, message = "住所は255文字以内で入力してください。")
    private String address;

}
