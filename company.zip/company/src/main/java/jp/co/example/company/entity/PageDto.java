package jp.co.example.company.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class PageDto {
    private int pageStart; // 시작 페이지 번호
    private int pageEnd; // 끝 페이지 번호
    private boolean prev; // "이전" 버튼 필요?
    private boolean next; // "다음" 버튼 필요?
    private int total; // 전체 글 개수
    private Criteria cri; // Criteria 포함

    public PageDto(Criteria cri, int total) {
        this.cri = cri;
        this.total = total;

        // 현재 페이지가 7이면 pageEnd = 10
        this.pageEnd = (int) (Math.ceil(cri.getPageNum() / 10.0)) * 10;

        // pageStart = pageEnd - 9
        this.pageStart = this.pageEnd - 9;

        int realEnd = (int) (Math.ceil(total * 1.0 / cri.getAmount()));

        // 실제 페이지보다 end가 더 크면 조정
        if (realEnd < pageEnd) {
            this.pageEnd = realEnd;
        }

        this.prev = pageStart > 1; // 시작이 1보다 크면 이전 페이지 있음
        this.next = pageEnd < realEnd; // 마지막보다 작으면 다음 페이지 있음
    }
}