package jp.co.example.company.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jp.co.example.company.entity.User;
import jp.co.example.company.form.UserUpdateForm;
import jp.co.example.company.service.LoginService;

@Controller
public class UserdetailController {

    @Autowired
    private LoginService loginService;

    @GetMapping("/admins/userDetail/{id}")
    public String showEditForm(
            @PathVariable("id") Long id,
            HttpSession session,
            Model model,
            HttpServletResponse response) throws Exception {

        User loginUser = (User) session.getAttribute("user");
        User user = (User) session.getAttribute("user");
        if (loginUser == null || loginUser.getAuthorityId() != 1) {
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            return "redirect:/user/search";
        }

        User userToEdit = loginService.findById(id);

        if (userToEdit == null) {
            return "error/404";
        }

        // User -> UserUpdateForm으로 복사
        UserUpdateForm form = new UserUpdateForm();
        form.setEmployeeName(userToEdit.getEmployeeName());
        form.setEmployeeNameKana(userToEdit.getEmployeeNameKana());
        form.setDepartmentId(userToEdit.getDepartmentId());
        form.setPhoneNumber(userToEdit.getPhoneNumber());
        form.setBirthDate(userToEdit.getBirthDate());
        form.setGender(userToEdit.getGender());
        form.setPostalCode(userToEdit.getPostalCode());
        form.setAddress(userToEdit.getAddress());

        model.addAttribute("userUpdateForm", form);
        model.addAttribute("employeeId", userToEdit.getEmployeeId()); // ID 별도로 전달
        model.addAttribute("isAdmin", user.getAuthorityId() == 1);
        model.addAttribute("loginId", user.getEmployeeName());
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        return "admins/userDetail";
    }

    @PostMapping("/admins/userUpdate/{id}")
    public String updateUser(
            @PathVariable("id") Long id,
            @Valid @ModelAttribute("userUpdateForm") UserUpdateForm form,
            BindingResult result,
            HttpSession session,
            Model model, RedirectAttributes redirectAttributes) {

        User loginUser = (User) session.getAttribute("user");
        if (loginUser == null || loginUser.getAuthorityId() != 1) {
            return "redirect:/user/search";
        }

        if (result.hasErrors()) {
            model.addAttribute("employeeId", id);
            return "admins/userDetail"; // 유효성 오류 시 폼으로
        }

        User user = loginService.findById(id);
        if (user == null) {
            return "error/404";
        }
        model.addAttribute("loginId", user.getEmployeeName());
        // form 데이터를 user 엔티티에 복사
        user.setEmployeeName(form.getEmployeeName());
        user.setEmployeeNameKana(form.getEmployeeNameKana());
        user.setDepartmentId(form.getDepartmentId());
        user.setPhoneNumber(form.getPhoneNumber());
        user.setBirthDate(form.getBirthDate());
        user.setGender(form.getGender());
        user.setPostalCode(form.getPostalCode());
        user.setAddress(form.getAddress());

        loginService.updateUser(user);
        redirectAttributes.addFlashAttribute("successMessage", "修正が完了しました。");

        return "redirect:/admins/userDetail/" + user.getEmployeeId();
    }
}
