package jp.co.example.company.controller;

import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jp.co.example.company.entity.User;
import jp.co.example.company.form.UserCreateform;

import jp.co.example.company.service.UserService;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class RegisterController {

    private final UserService userService;

    private boolean isAdmin(HttpSession session) {
        User user = (User) session.getAttribute("user");
        return user != null && user.getAuthorityId() == 1;
    }

    @PostMapping("/admins/adminCreate")
    public String registerUser(@Valid UserCreateform form, BindingResult result, Model model,
            HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session))
            return "redirect:/login";

        if (result.hasErrors()) {
            // 에러 메시지 리스트 생성
            var errorMessages = result.getFieldErrors().stream()
                    .filter(e -> !(e.getField().equals("birthDate") && "typeMismatch".equals(e.getCode())))
                    .map(e -> e.getDefaultMessage())
                    .collect(Collectors.toList());
            User user = (User) session.getAttribute("user");
            model.addAttribute("userForm", form);
            model.addAttribute("validationErrors", errorMessages);
            model.addAttribute("isAdmin", user.getAuthorityId() == 1);
            return "admins/adminCreate";
        }

        try {
            Long employeeId = userService.join(form);
            redirectAttributes.addFlashAttribute("successMessage", "社員ID " + employeeId + " が登録されました。");
            return "redirect:/admins/adminCreate";

        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            e.printStackTrace();
            model.addAttribute("errorMessage", "ログインIDが既に使用されています。別のIDを入力してください。");
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorMessage", "登録に失敗しました: " + e.getMessage());
        }

        model.addAttribute("userForm", form);
        return "admins/adminCreate";
    }

    @GetMapping("/admins/adminCreate")
    public String registerForm(
            HttpSession session,
            Model model,
            @ModelAttribute("successMessage") String successMessage,
            @ModelAttribute("errorMessage") String errorMessage) {

        if (!isAdmin(session))
            return "redirect:/login";

        // 로그인 중인 사용자 정보 표시용
        User user = (User) session.getAttribute("user");
        model.addAttribute("isAdmin", user.getAuthorityId() == 1);
        model.addAttribute("loginId", user.getEmployeeName());

        // Flash属性をModelに追加
        if (successMessage != null && !successMessage.isBlank()) {
            model.addAttribute("successMessage", successMessage);
        }
        if (errorMessage != null && !errorMessage.isBlank()) {
            model.addAttribute("errorMessage", errorMessage);
        }

        // form이 없으면 새로 생성
        if (!model.containsAttribute("userForm")) {
            model.addAttribute("userForm", new UserCreateform());
        }

        return "admins/adminCreate";
    }

}
