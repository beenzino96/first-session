package jp.co.example.company.form;

import java.sql.Date;
import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserRegisterForm {

    @NotBlank(message = "氏名を入力してください。")
    @Size(max = 100, message = "氏名は100文字以内で入力してください。")
    private String employeeName;

    @NotBlank(message = "氏名（カナ）を入力してください。")
    @Size(max = 100, message = "氏名（カナ）は100文字以内で入力してください。")
    private String employeeNameKana;

    @NotNull(message = "部署IDを入力してください。")
    @Min(value = 1, message = "部署IDは1以上の数字で入力してください。")
    private Integer departmentId;

    @Size(max = 20, message = "電話番号は20文字以内で入力してください。")
    private String phoneNumber;

    @NotBlank(message = "ログインIDを入力してください。")
    @Size(max = 50, message = "ログインIDは50文字以内で入力してください。")
    private String loginId;

    @NotBlank(message = "パスワードを入力してください。")
    @Size(min = 8, max = 100, message = "パスワードは8〜100文字で入力してください。")
    private String loginPassword;

    @NotNull(message = "権限IDを入力してください。")
    @Min(value = 1, message = "権限IDは1以上の数字で入力してください。")
    private Integer authorityId;

    @NotNull(message = "生年月日を入力してください。")
    private Date birthDate; // LocalDate 형태로 문자열을 받는 것으로 가정 (yyyy-MM-dd)

    @Pattern(regexp = "^[MFO]$", message = "性別は「M」「F」「O」のいずれかを入力してください。")
    private Character gender;

    @Size(max = 10, message = "郵便番号は10文字以内で入力してください。")
    @Pattern(regexp = "^\\d{3}-?\\d{4}$", message = "郵便番号は正しい形式（例: 123-4567）で入力してください。")
    private String postalCode;

    @Size(max = 255, message = "住所は255文字以内で入力してください。")
    private String address;
}
