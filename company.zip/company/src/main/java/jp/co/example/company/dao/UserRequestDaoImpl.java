package jp.co.example.company.dao;

import jp.co.example.company.entity.UserRequest;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.stereotype.Repository;

@Repository
public class UserRequestDaoImpl implements UserReqeustDao {
    private JdbcTemplate jdbcTemplate;

    public UserRequestDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<UserRequest> findAllUserRequest() {
        String sql = "SELECT * FROM myschema.user_requests " +
                "ORDER BY CASE status " +
                "WHEN '未対応' THEN 1 " +
                "WHEN '対応中' THEN 2 " +
                "WHEN '対応不可' THEN 3 " +
                "WHEN '対応済み' THEN 4 " +
                "ELSE 5 END ASC, id ASC";
        List<UserRequest> ID = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(UserRequest.class));
        return ID;
    }

    @Override
    public void updateStatus(int id, String status) {
        String sql = "UPDATE myschema.user_requests SET status = ? WHERE id = ?";
        jdbcTemplate.update(sql, status, id);
    }
}
