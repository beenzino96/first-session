package jp.co.example.company.dao;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import jp.co.example.company.entity.Admin;
import jp.co.example.company.entity.User;

@Repository
public class UserDaoImpl implements UserDao {
    private JdbcTemplate jdbcTemplate;

    private static final String SELECT_BY_USER_ID = "SELECT * FROM myschema.users WHERE login_id = ?";
    private static final String SELECT_BY_AUTHORITY_ID = "SELECT * FROM myschema.permissions WHERE authority_id = ?";

    public UserDaoImpl(JdbcTemplate jdbcTemplate) { // 데이터를 직접 받아올수 있게 써야지 생성자로
        this.jdbcTemplate = jdbcTemplate; // UserDaoImpl 생성이 되면 저장
    }

    @Override
    public User findByLoginId(String loginId) {
        RowMapper<User> rowMapper = new BeanPropertyRowMapper<>(User.class);
        try { // 이건 DB에서 가져온 데이터를 User 객체로 바꿔주는 도구예요.

            return jdbcTemplate.queryForObject(SELECT_BY_USER_ID, rowMapper, loginId);

        } catch (Exception e) {
            e.printStackTrace(); // 로그 확인
            return null; // 사용자 없음
        } /*
           * 이 줄이 실제로 DB에 "사용자 정보 좀 줘!"라고 요청하는 부분이에요.
           * 
           * SELECT_BY_USER_ID라는 SQL문을 실행하면서 userId를 넣고, 결과를 User 객체로 변환해서 돌려줘요.
           */
    }

    @Override
    public Admin findByAuthorityId(Integer authorityId) {
        RowMapper<Admin> rowMapper = new BeanPropertyRowMapper<>(Admin.class);
        try {
            return jdbcTemplate.queryForObject(SELECT_BY_AUTHORITY_ID, rowMapper, authorityId);
        } catch (Exception e) {
            e.printStackTrace(); // 로그 확인
            return null;
        }

    }

    @Override
    public List<User> findAll() {
        String sql = "SELECT * FROM myschema.users ORDER BY employee_id";
        List<User> users = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(User.class));
        return users;
    }

    @Override
    public User findById(Long id) {
        String sql = "SELECT * FROM myschema.users WHERE employee_id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(User.class), id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void update(User user) {
        String sql = "UPDATE myschema.users SET "
                + "employee_name = ?, "
                + "employee_name_kana = ?, "
                + "department_id = ?, "
                + "phone_number = ?, "
                + "birth_date = ?, "
                + "gender = ?, "
                + "postal_code = ?, "
                + "address = ? "
                + "WHERE employee_id = ?";

        jdbcTemplate.update(sql,
                user.getEmployeeName(),
                user.getEmployeeNameKana(),
                user.getDepartmentId(),
                user.getPhoneNumber(),
                user.getBirthDate(),
                user.getGender(),
                user.getPostalCode(),
                user.getAddress(),
                user.getEmployeeId());
    }
}
