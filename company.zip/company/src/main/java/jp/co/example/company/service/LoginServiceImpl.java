package jp.co.example.company.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.example.company.dao.UserDao;
import jp.co.example.company.entity.Admin;
import jp.co.example.company.entity.User;

@Service
public class LoginServiceImpl implements LoginService {
    @Autowired
    private UserDao userDao;

    @Override
    public User login(String loginId, String password) {
        System.out.println("로그인 시도 ID: " + loginId);
        System.out.println("입력된 비밀번호: " + password);

        User user = userDao.findByLoginId(loginId);

        if (user != null) {
            System.out.println("DB에 저장된 비밀번호: " + user.getLoginPassword());
        }

        if (user != null && user.getLoginPassword().equals(password)) {
            System.out.println("로그인 성공");
            return user;
        }

        System.out.println("로그인 실패");
        return null;
    }

    @Override
    public Admin login(Integer authorityId, String authorityName) {
        Admin admin = userDao.findByAuthorityId(authorityId);
        if (admin != null && admin.getAuthorityName().equals(authorityName)) {
            return admin;
        }
        return null;
    }

    @Override
    public List<User> findAll() {
        return userDao.findAll();
    }

    @Override
    public User findById(Long id) {
        return userDao.findById(id);
    }

    @Override
    public void updateUser(User user) {
        System.out.println("Updating user: " + user);
        userDao.update(user); // JPA 사용하는 경우
    }
}
