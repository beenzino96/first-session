package jp.co.example.company.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "permissions", schema = "myschema")
@Getter
@Setter
public class Admin {
    @Id
    @Column(name = "authority_id")
    private Integer authorityId;

    @Column(name = "authority_name")
    private String authorityName;

    public Admin() {

    }

    public Admin(Integer authorityId, String authorityName) {

    }
}
