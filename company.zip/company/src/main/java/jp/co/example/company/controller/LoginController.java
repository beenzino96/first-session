package jp.co.example.company.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jp.co.example.company.entity.User;
import jp.co.example.company.form.UserForm;
import jp.co.example.company.service.LoginService;

@Controller
public class LoginController {

    private final LoginService loginService;

    @Autowired
    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    @GetMapping("/login")
    public String loginPage() {
        return "user/login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute UserForm userForm,
            HttpSession session,
            Model model,
            HttpServletResponse response,
            RedirectAttributes redirectAttributes) {

        String loginId = userForm.getLoginId();
        String password = userForm.getLoginPassword();

        User user = loginService.login(loginId, password);

        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        if (user != null) {
            session.setAttribute("user", user);
            if (user.getAuthorityId() == 1) {
                return "redirect:/admins/admin";
            } else {
                return "redirect:/user/search";
            }
        }

        // 오류 메시지를 flash attribute로 전달
        redirectAttributes.addFlashAttribute("errorMessage", "IDまたはパスワードが正しくありません");
        return "redirect:/login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login?error=unauthorized";

    }
}
