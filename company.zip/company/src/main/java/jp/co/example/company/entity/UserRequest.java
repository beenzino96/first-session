package jp.co.example.company.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "user_requests", schema = "myschema")
@Getter
@Setter
public class UserRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // AUTO_INCREMENT 대응
    @Column(name = "id")
    private Integer id; // 게시물 고유 번호

    @Column(name = "employee_id")
    private Long employeeId; // 사용자 FK

    @Column(name = "login_id")
    private String loginId;

    @Column(name = "request_content")
    private String requestContent;

    @Column(name = "message")
    private String message;

    @Column(name = "status")
    private String status;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "request_time")
    private Date requestTime;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "change_time")
    private Date changeTime;
}
