package jp.co.example.company.service;

import jp.co.example.company.entity.User;
import jp.co.example.company.form.UserCreateform;
import jp.co.example.company.form.UserRegisterForm;
import jp.co.example.company.form.UserUpdateForm;

public interface UserService {
    Long join(UserCreateform form);

}
