package jp.co.example.company.dao;

import java.util.List;

import jp.co.example.company.entity.UserRequest;

public interface UserReqeustDao {
    List<UserRequest> findAllUserRequest();

    void updateStatus(int id, String status);
}
