package jp.co.example.company.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.example.company.form.UserCreateform;
import jp.co.example.company.form.UserRegisterForm;
import jp.co.example.company.form.UserUpdateForm;
import jp.co.example.company.entity.User;
import jp.co.example.company.entity.UserRepository;
import lombok.RequiredArgsConstructor;

import java.sql.Date;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    @Transactional
    public Long join(UserCreateform form) {
        User user = new User();

        // ❌ 제거: user.setEmployeeId(newEmployeeId);

        user.setEmployeeName(form.getEmployeeName());
        user.setEmployeeNameKana(form.getEmployeeNameKana());
        user.setLoginId(form.getLoginId());
        user.setLoginPassword(form.getLoginPassword());
        user.setAuthorityId(form.getAuthorityId());
        user.setDepartmentId(form.getDepartmentId());
        user.setPhoneNumber(form.getPhoneNumber());
        user.setBirthDate(form.getBirthDate());
        user.setGender(form.getGender());
        user.setPostalCode(form.getPostalCode());
        user.setAddress(form.getAddress());

        user.setDeletedFlag(false); // ← 초기 등록 시 false 추천

        userRepository.save(user);

        return user.getEmployeeId(); // DB에서 자동 생성된 값 반환
    }

}
