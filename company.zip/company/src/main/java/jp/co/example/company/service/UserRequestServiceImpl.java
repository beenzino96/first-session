package jp.co.example.company.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.example.company.dao.UserReqeustDao;
import jp.co.example.company.entity.UserRequest;
import jp.co.example.company.mapper.PageMapper;

@Service
public class UserRequestServiceImpl implements UserRequestService {

    @Autowired
    private UserReqeustDao userReqeustDao;
    @Autowired
    private PageMapper pageMapper;

    @Override
    public List<UserRequest> findUserRequests() {
        return userReqeustDao.findAllUserRequest();

    }

    @Override
    public void updateStatus(int id, String status) {
        userReqeustDao.updateStatus(id, status);
    }

    @Override
    public void saveRequest(UserRequest request) {
        pageMapper.insertRequest(request);
    }
}
