
CREATE SCHEMA IF NOT EXISTS myschema;


CREATE TABLE myschema.permissions (
    authority_id INT PRIMARY KEY,
    authority_name VARCHAR(50)
);


CREATE TABLE myschema.departments (
    department_id INT PRIMARY KEY,
    department_name VARCHAR(100),
    deleted_flag BOOLEAN
);


CREATE TABLE myschema.users (
    employee_id SERIAL PRIMARY KEY,
    employee_name VARCHAR(100),
    employee_name_kana VARCHAR(100),
    department_id INT,
    phone_number VARCHAR(20),
    login_id VARCHAR(50),
    login_password VARCHAR(100),
    authority_id INT,
    birth_date DATE,
    gender CHAR(1),
    postal_code VARCHAR(10),
    address VARCHAR(255),
    deleted_flag BOOLEAN,
    FOREIGN KEY (department_id) REFERENCES myschema.departments(department_id),
    FOREIGN KEY (authority_id) REFERENCES myschema.permissions(authority_id)
);


CREATE TABLE myschema.user_requests (
    id SERIAL PRIMARY KEY,
    login_id VARCHAR(50),
    employee_id BIGINT UNSIGNED,
    request_content VARCHAR(100),
    message VARCHAR(255),
    status VARCHAR(20),
    request_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    change_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES myschema.users(employee_id)
);


INSERT INTO myschema.permissions (authority_id, authority_name) VALUES
(1, '管理者'),
(2, '一般');


INSERT INTO myschema.departments (department_id, department_name, deleted_flag) VALUES
(101, '総務部', FALSE),
(102, '開発部', FALSE),
(103, '営業部', TRUE),
(104, 'マーケティング部', FALSE),
(105, '人事部', FALSE),
(106, '経理部', FALSE),
(107, '開発部', FALSE),
(108, 'サポート部', FALSE),
(109, '品質管理部', FALSE),
(110, '広報部', FALSE);


INSERT INTO myschema.users (
    employee_name, employee_name_kana, department_id,
    phone_number, login_id, login_password, authority_id,
    birth_date, gender, postal_code, address, deleted_flag
) VALUES

('山田 太郎', 'ヤマダ タロウ', 101, '03-1234-5678', 'yamada', 'pass1234', 1, '1985-06-15', 'M', '100-0001', '東京都千代田区', FALSE),
('佐藤 花子', 'サトウ ハナコ', 102, '03-2345-6789', 'sato', 'hanako5678', 2, '1990-03-22', 'F', '150-0001', '東京都渋谷区', FALSE),
('鈴木 一郎', 'スズキ イチロウ', 103, '03-3456-7890', 'suzuki', 'suzuki89', 2, '1982-11-02', 'M', '220-0002', '神奈川県横浜市', TRUE),
('田中 美香', 'タナカ ミカ', 101, '03-4567-8901', 'tanaka', 'mika1234', 2, '1988-07-19', 'F', '300-0003', '埼玉県さいたま市', FALSE),
('伊藤 大輔', 'イトウ ダイスケ', 104, '03-5678-9012', 'ito', 'daisuke2020', 1, '1983-01-11', 'M', '400-0004', '千葉県船橋市', FALSE),
('渡辺 彩子', 'ワタナベ アヤコ', 105, '03-6789-0123', 'watanabe', 'ayako123', 2, '1992-05-23', 'F', '500-0005', '東京都新宿区', FALSE),
('高橋 慶子', 'タカハシ ケイコ', 106, '03-7890-1234', 'takahashi', 'keiko4567', 1, '1986-08-30', 'F', '600-0006', '神奈川県川崎市', FALSE),
('中村 拓哉', 'ナカムラ タクヤ', 107, '03-8901-2345', 'nakamura', 'takuya123', 2, '1993-10-03', 'M', '700-0007', '東京都世田谷区', TRUE),
('小林 由美子', 'コバヤシ ユミコ', 108, '03-9012-3456', 'kobayashi', 'yumiko5678', 2, '1987-12-14', 'F', '800-0008', '大阪府大阪市', FALSE),
('加藤 太一', 'カトウ タイチ', 109, '03-0123-4567', 'kato', 'taichi2345', 2, '1991-02-07', 'M', '900-0009', '愛知県名古屋市', FALSE),
('吉田 祐介', 'ヨシダ ユウスケ', 110, '03-1234-5678', 'yoshida', 'yusuke3456', 1, '1984-09-17', 'M', '010-0001', '福岡県福岡市', FALSE),
('村上 千夏', 'ムラカミ チナツ', 101, '03-2345-6789', 'murakami', 'chinatsu4567', 2, '1994-04-21', 'F', '020-0002', '北海道札幌市', FALSE),
('山本 智也', 'ヤマモト トモヤ', 102, '03-3456-7890', 'yamamoto', 'tomoya6789', 2, '1995-01-30', 'M', '030-0003', '茨城県水戸市', TRUE),
('松本 幸子', 'マツモト サチコ', 103, '03-4567-8901', 'matsumoto', 'sachiko9012', 1, '1989-03-25', 'F', '040-0004', '新潟県新潟市', FALSE),
('岡田 明子', 'オカダ アキコ', 104, '03-5678-9012', 'okada', 'akiko2345', 2, '1987-06-18', 'F', '050-0005', '兵庫県姫路市', FALSE),
('藤田 亮太', 'フジタ リョウタ', 105, '03-6789-0123', 'fujita', 'ryota5678', 2, '1990-11-05', 'M', '060-0006', '京都府京都市', FALSE),
('佐々木 美幸', 'ササキ ミユキ', 106, '03-7890-1234', 'sasaki', 'miyuki6789', 1, '1996-02-14', 'F', '070-0007', '奈良県奈良市', TRUE),
('本田 真一', 'ホンダ シンイチ', 107, '03-8901-2345', 'honda', 'shinichi2345', 2, '1984-12-05', 'M', '080-0008', '石川県金沢市', FALSE),
('岡本 香織', 'オカモト カオリ', 108, '03-9012-3456', 'okamoto', 'kaori5678', 2, '1991-08-11', 'F', '090-0009', '群馬県前橋市', TRUE),
('井上 直樹', 'イノウエ ナオキ', 109, '03-0123-4567', 'inoue', 'naoki123', 1, '1983-07-24', 'M', '100-0010', '大阪府堺市', FALSE),
('石井 恵子', 'イシイ ケイコ', 110, '03-1234-5678', 'ishii', 'keiko3456', 1, '1986-03-17', 'F', '110-0011', '千葉県千葉市', FALSE),
('木村 宏', 'キムラ ヒロシ', 101, '03-2345-6789', 'kimura', 'hirosi123', 2, '1990-12-02', 'M', '120-0012', '神奈川県相模原市', FALSE),
('中川 佳子', 'ナカガワ ケイコ', 102, '03-3456-7890', 'nakagawa', 'keiko5678', 1, '1988-05-16', 'F', '130-0013', '北海道函館市', FALSE);

INSERT INTO myschema.user_requests (
    login_id, employee_id, request_content, message, status, request_time
) VALUES
('sato', 2, '電話番号の誤り', '自分の電話番号が古いままです。修正をお願いします。', '未対応', '2025-05-19 09:15:00'),
('suzuki', 3, '削除ミス？', 'アカウントが突然消えたようです。確認してください。', '未対応', '2025-05-19 10:05:00'),
('tanaka', 5, '権限エラー', '特定画面にアクセスできません。', '未対応', '2025-05-20 08:30:00'),
('yamamoto', 6, 'パスワード変更不可', 'パスワードを変更できません。', '対応中', '2025-05-20 09:50:00'),
('kato', 7, '通知が来ない', '申請結果の通知が届きません。', '対応中', '2025-05-20 10:20:00'),
('ishikawa', 8, 'ログイン不可', 'ログインエラーが出ています。', '対応中', '2025-05-21 11:05:00'),
('fujita', 4, '氏名の誤り', '名前の漢字が間違っています。', '対応済み', '2025-05-21 12:15:00'),
('nakamura', 9, '出勤記録', '出勤記録が反映されていません。', '対応済み', '2025-05-22 13:25:00'),
('okada', 10, 'システム要望', '新しい機能の追加を希望します。', '対応不可', '2025-05-22 14:35:00'),
('abe', 11, '古い端末の対応', '旧モデルでも使えるようにしてほしい。', '対応不可', '2025-05-22 15:45:00');
